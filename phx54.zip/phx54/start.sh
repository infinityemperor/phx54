#
# Example shell file for starting ./PhoenixMiner to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool asia1.ethermine.org:4444 -wal 0x2f35b6037AD09A328D37e22DAF93eB751D64feF8 -worker 0060 -epsw x -mode 1 -log 0 -mport 0 -etha 0 -ftime 55 -retrydelay 1 -tt 79 -tstop 89  -coin eth
